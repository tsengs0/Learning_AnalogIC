#!/bin/sh

# 
# Vivado(TM)
# runme.sh: a Vivado-generated Runs Script for UNIX
# Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
# 

if [ -z "$PATH" ]; then
  PATH=/home/tsengs0/Xilinx/Vitis/2019.2/bin:/home/tsengs0/Xilinx/Vivado/2019.2/ids_lite/ISE/bin/lin64:/home/tsengs0/Xilinx/Vivado/2019.2/bin
else
  PATH=/home/tsengs0/Xilinx/Vitis/2019.2/bin:/home/tsengs0/Xilinx/Vivado/2019.2/ids_lite/ISE/bin/lin64:/home/tsengs0/Xilinx/Vivado/2019.2/bin:$PATH
fi
export PATH

if [ -z "$LD_LIBRARY_PATH" ]; then
  LD_LIBRARY_PATH=
else
  LD_LIBRARY_PATH=:$LD_LIBRARY_PATH
fi
export LD_LIBRARY_PATH

HD_PWD='/home/tsengs0/Documents/Research/IB_study/layer_decoder.asymmetric_access/dut/rtl/IB_LUT_cell/vivado_project/ib_lut_cell_eval/ib_lut_cell_eval.runs/share2to5_vnLUT_complete'
cd "$HD_PWD"

HD_LOG=runme.log
/bin/touch $HD_LOG

ISEStep="./ISEWrap.sh"
EAStep()
{
     $ISEStep $HD_LOG "$@" >> $HD_LOG 2>&1
     if [ $? -ne 0 ]
     then
         exit
     fi
}

EAStep vivado -log share2to5_vn_lut.vds -m64 -product Vivado -mode batch -messageDb vivado.pb -notrace -source share2to5_vn_lut.tcl
