#!/bin/bash

source /home/tsengs0/Xilinx/Vivado/2019.2/settings64.sh
