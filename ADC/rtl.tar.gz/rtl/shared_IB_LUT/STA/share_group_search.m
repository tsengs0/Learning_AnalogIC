clc;clear;
Fx_num = 2;
Fx_vec = [2 3];
Fx = 0;
N = 204;%765;
ib_lut_num = Fx_vec(Fx+1);
A = [1, 2, 3, 4, 6, 12, 17, 34, 51, 68, 102, 204];%[1, 3, 5, 9, 15, 17, 45, 51, 85, 153, 255, 765];
num = size(A, 2);
K_prime = zeros(1, num);
K = zeros(1, num);
K_1 = zeros(1, num);
for i = 1:num
  K_prime(i) = N / A(i);
  K(i) = lcm(ib_lut_num, K_prime(i));
  K_1(i) = ib_lut_num*K_prime(i);
end

[A;K_prime;K;K_1]

clc;clear;
N = 204;
Fx = 0;
if Fx == 0
  K=[2 4 6 12 34 68 102];
  lut_K = [1 2 6 34 39 55];
else % Fx = 1
  K=[3 6 12 51 102];
  %K_mul = [68 34 17 4 2]
  lut_K = [2 3 6 48 55];
end

K_size = size(K, 2);
K_mul = zeros(1, K_size);
for i = 1:K_size
  K_mul(i) = N / K(i);
end

for i=K_size:-1:1
  mul_fac = zeros(1, i-1);
  lut_num = zeros(1, i-1);
  lut_num_all_vn = zeros(1, i-1);
  K_base = K(i);
  
  for j=(i-1):-1:1
    temp = K_base / K(j);
    temp_rem = mod(K_base, K(j));
    if temp_rem ~= 0
      mul_fac(j) = -1;
      lut_num(j) = -1;
      lut_num_all_vn(j) = -1;
    else
      mul_fac(j) = temp;
      lut_num(j) = mul_fac(j)*lut_K(j);
      lut_num_all_vn(j) = lut_num(j)*K_mul(i);
    end
  end
  disp(K_base)
  disp(K(1:1:i-1))
  disp(mul_fac)
  disp(lut_num)
  disp(lut_num_all_vn)
end

lut_0_max = max(lut_0);
for i=1:x_size
  lut_base(i) = lut_0_max;
end
figure;
grid;
plot(x, lut_base, '-r+', x, lut_1, '-g*');

  K_prime = 204   102    68    51    34    17    12     6     4     3     2     1
  K=        204   102   204    51   102    51    12     6    12     3     6     3   2   4   34    68
  LUT =                             55     48     6     3     6     2     3     2   1   2   34    39
  
 102
    3    6   12   51
   34   17   -1    2
   68     -1   96
   136   102    -1   192
   
 51
    3    6   12
   17   -1   -1
   34   -1   -1
   136    -1    -1
   
 12
   3   6
   4   2
   8   6
   136   102
   
 6
 3
 2
 4
 136
 /////////////////////////////////////////////////
  102
    2    4    6   12   34   68
   51   -1   17   -1    3   -1
    51    -1   102    -1   117    -1
   102    -1   204    -1   234    -1
   
 68
    2    4    6   12   34
   34   17   -1   -1    2
   34   34   -1   -1   78
   102   102    -1    -1   234
   
 34
    2    4    6   12
   17   -1   -1   -1
   17   -1   -1   -1
   102    -1    -1    -1
   
 12
   2   4   6
   6   3   2
    6    6   12
   102   102   204
   
 6
   2   4
   3  -1
   3  -1
   102    -1
   
 4
 2
 2
 2
 102 
 

 ==================================
 F0.K=4
  LUT: 57 -> 5814 (204.102)
 FF: 34  -> 3468 (204.102)
 ----------------------------------
 F1.K=4
 LUT: 57 -> 8721 (204.102)
 FF: 34  -> 5202 (204.102)
 ==================================
 Total:
 LUT: 14,535
 Logic LUT: 11475
 LUTRAM: 3060
 FF: 8,670
 ==================================

 ================================== 
 F0.K=2
 LUT: 21 -> 4284 (204.102)
 Logic LUT: 3060
 LUTRAM: 1224
 FF:  5 -> 1020 (204.102)
 ================================== 
 F1.K=6
 LUT: 50 -> 5100 (204.102)
 Logic LUT: 3264
 LUTRAM: 1836
 FF: 15  -> 1530 (204.102)
 ==================================
  Total:
  LUT: 9384
  Logic LUT: 6324
  LUTRAM: 3060
  FF: 2550
 ==================================
 
 grid;
 K = [44, 26];
 LogicLUT = [11475 6324];
 plot(K, LogicLUT);
   